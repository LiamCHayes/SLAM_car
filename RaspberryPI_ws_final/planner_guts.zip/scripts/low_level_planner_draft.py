#!/usr/bin/env python3

import rospy
import numpy as np
import math
import time
from gpiozero import Motor
from planner.srv import *

def distance_calc(self, state_goal):
    self.x_goal = state_goal[0,0]
    self.y_goal = state_goal[1,0]

    #if NN local
    dist = np.sqrt((self.x_goal)**2 + (self.y_goal)**2)
    angle_desired = math.arctan(abs(self.y_goal)/abs(self.x_goal))

    return dist, angle_desired


def serial_write(dist, angle_desired, dist_unit, angle_unit):
    left_side_front = Motor(forward=4, backward=14) ## TEMP
    left_side_back = Motor(forward=4,backward=14) ## TEMP
    right_side_front = Motor(forward=4, backward=14) ## TEMP
    right_side_back = Motor(forward=4,backward=14) ## TEMP

    dist_time = round(dist * dist_unit, 2)
    angle_time = round(angle_desired * angle_unit, 2)

    #Angle serial commands
    timer = angle_time
    if angle_desired >= 180:
        left_side_front.backward()
        left_side_back.backward()
        right_side_front.forward()
        right_side_back.forward()
    else:
        left_side_front.forward()
        left_side_back.forward()
        right_side_front.backward()
        right_side_back.backward()
    time.sleep(timer)
    timer = 0
    left_side_front.stop()
    left_side_back.stop()
    right_side_front.stop()
    right_side_back.stop()
    
    #Dist serial commands
    timer = dist_time
    left_side_front.forward()
    left_side_back.forward()
    right_side_front.forward()
    right_side_back.forward()
    time.sleep(timer)
    timer = 0
    left_side_front.stop()
    right_side_front.stop()
    left_side_back.stop()
    right_side_back.stop()



if __name__ == "__main__":
    unit_distance_movement = 1.3667 # time to travel 1 meter t/m
    unit_angle_change_rad = 0.0995 # time to rotate 2pi rad t/rad
    unit_ange_change_deg = 0.001736 # time to rotate 360 deg t/deg

    print('waiting')
    while True:
        rospy.wait_for_service('NN_goal')
        print('serviced')
        state_goal_req = rospy.ServiceProxy('NN_goal', coords_srv)
        state_goal_resp = state_goal_req(0,0)
        state_goal = np.array([[state_goal_resp.x_goal/100],[state_goal_resp.y_goal/100]])
        print(state_goal)
        
        dist_desired, angle_desired = distance_calc(state_goal)
        serial_write(dist_desired, angle_desired, unit_distance_movement, unit_angle_change)
